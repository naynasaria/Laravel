<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Animais</title>
    </head>
    <body>
        <h1>Cadastro de Cachorros</h1>

        <label for="lblNome">Nome do Animal:</label>
        <input type="text" name="nome" value="{{ $animal->nome }}">
        <br><br>
        <label for="lblRaca">Raça:</label>
        <input type="text" name="raca" value="{{ $animal->raca }}">
        <br><br>
        <label for="lblIdade">Idade:</label>
        <input type="text" name="idade" value="{{ $animal->idade }}">
        <br><br>
    </body>
</html>
