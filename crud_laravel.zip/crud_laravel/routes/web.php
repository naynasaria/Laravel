<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Models\Produto;
use Illuminate\Http\Request;

Route::get('/', function () {
    return view('inicio');
});

Route::post('/cadastrar-animal',function(Request $request){
    //dd($request->all());

    Animal::create([
        'nome' => $request->nome,
        'raca' => $request->raca,
        'idade' => $request->idade
    ]);

    echo "Cachorro cadastrado com sucesso!";
});

Route::get('/listar-animal/{id}', function($id){
    //dd(Produto::find($id)); //debug and die
    $animal = Animal::find($id);
    return view('listar', ['animal' => $animal]);
});

Route::get('/editar-animal/{id}', function($id){
    //dd(Produto::find($id)); //debug and die
    $animal= Animal::find($id);
    return view('editar', ['animal' => $animal]);
});

Route::post('/editar-animal/{id}',function(Request $request, $id){
    //dd($request->all());
    $animal = Animal::find($id);

    $animal->update([
        'nome' => $request->nome,
        'raca' => $request->raca,
        'idade' => $request->idade
    ]);

    echo "Animal editado com sucesso!";
});

Route::get('/excluir-animal/{id}',function($id){
    //dd($request->all());
    $animal = Animal::find($id);
    $animal->delete();

    echo "Animal excluido com sucesso!";
});