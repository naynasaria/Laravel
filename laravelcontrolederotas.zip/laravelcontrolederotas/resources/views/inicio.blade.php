<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

    </head>
    <body class="antialiased">
        <h1>Produtos</h1>
		
        <form action="/cadastrar-produto" method="POST">
            @csrf
    		<label for="lblNome" >Nome:</label>
	    	<input type="text" name="nome" value="{{ $produto->nome }}" />
		    <br><br>
		
    		<label for="lblValor" >Valor:</label>
	    	<input type="text" name="valor" value="{{ $produto->valor }}" />
		    <br><br>
		
    		<label for="lblQuantidade" >Quantidade:</label>
	    	<input type="text" name="estoque" value="{{ $produto->estoque }}" />
		    <br><br>
        </form>
		
    </body>
</html>
